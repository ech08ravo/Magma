Optional. Put unit-guide PDFs here, one per unit, named with the unit code
(for example SRT141.pdf). The PDFs must contain readable text, not scans.

In the dashboard's upload window, tick "Also scan a local Unit-Guides folder"
and choose this folder. Guides are read in your browser and are not uploaded.
