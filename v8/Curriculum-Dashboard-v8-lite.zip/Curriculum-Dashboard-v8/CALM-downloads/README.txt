Save the files you download from CALM in this folder, keeping CALM's file names:

  Student Pathways by Units.xlsx   (required)
  Units by Assessment Tasks.xlsx   (required)
  Course Data.xlsx                 (optional; adds course names)

Then open curriculum-dashboard-v8.html, click "Upload CALM files",
select these files together and click "Apply to Model".
Other CALM files in this folder are skipped, so you don't need to remove them.
